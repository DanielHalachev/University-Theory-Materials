package bg.sofia.uni.fmi.mjt.wish.list;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class WishListServer {

    private Selector selector;
    private boolean isStopped;

    private final int serverPort;
    private final CommandManager commandManager;
    private final ConnectionManager connectionManager;

    private static final String SERVER_HOST = "localhost";
    private static final int BUFFER_SIZE = 1024;

    public WishListServer(int port) {
        connectionManager = new ConnectionManager();
        commandManager = new CommandManager(connectionManager);
        serverPort = port;
        isStopped = false;
    }

    public void start() {
        try (ServerSocketChannel server = ServerSocketChannel.open()) {
            server.bind(new InetSocketAddress(SERVER_HOST, serverPort));
            server.configureBlocking(false);

            selector = Selector.open();
            server.register(selector, SelectionKey.OP_ACCEPT);

            ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);
            while (!isStopped) {
                int readyChannels = selector.select();
                if (isStopped) {
                    break;
                }
                if (readyChannels == 0) {
                    continue;
                }

                Set<SelectionKey> selectedKeys = selector.selectedKeys();
                Iterator<SelectionKey> keyIterator = selectedKeys.iterator();

                while (keyIterator.hasNext()) {
                    SelectionKey key = keyIterator.next();
                    if (key.isReadable()) {
                        SocketChannel sc = (SocketChannel) key.channel();

                        buffer.clear();
                        int bytesRead = sc.read(buffer);
                        if (bytesRead <= 0) {
                            sc.close();
                            break;
                        }

                        buffer.flip();
                        byte[] destination = new byte[bytesRead - 1];
                        buffer.get(destination, 0, bytesRead - 1);
                        String message = new String(destination);
                        String response = commandManager.process(message, key) + "\n";

                        buffer.clear();
                        buffer.put(response.getBytes());

                        buffer.flip();
                        sc.write(buffer);

                        if (message.equals("disconnect")) {
                            connectionManager.removeConnection(key);
                            sc.close();
                            key.cancel();
                        }

                    } else if (key.isAcceptable()) {
                        ServerSocketChannel sockChannel = (ServerSocketChannel) key.channel();
                        SocketChannel accept = sockChannel.accept();
                        accept.configureBlocking(false);
                        accept.register(selector, SelectionKey.OP_READ);
                    }

                    keyIterator.remove();
                }
            }
        } catch (IOException e) {
            System.out.println("There is a problem with the server socket.");
            e.printStackTrace();
        }
    }

    public void stop() {
        isStopped = true;
        selector.wakeup();
    }

    public static void main(String[] args) {
        WishListServer wishListServer = new WishListServer(7777);

        Thread newThread = new Thread(wishListServer::start);
        newThread.start();
    }

}
