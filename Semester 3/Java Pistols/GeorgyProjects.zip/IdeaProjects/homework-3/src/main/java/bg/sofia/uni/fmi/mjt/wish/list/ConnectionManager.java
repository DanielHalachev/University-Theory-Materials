package bg.sofia.uni.fmi.mjt.wish.list;

import java.nio.channels.SelectionKey;
import java.util.HashMap;
import java.util.Map;

public class ConnectionManager {

    private final Map<SelectionKey, String> log;

    public ConnectionManager() {
        log = new HashMap<>();
    }

    public void addConnection(SelectionKey key, String username) {
        log.put(key, username);
    }

    public void removeConnection(SelectionKey key) {
        log.remove(key);
    }

    public boolean isNotLoggedIn(SelectionKey key) {
        return !log.containsKey(key);
    }

    public String getUsername(SelectionKey key) {
        return log.get(key);
    }
}
