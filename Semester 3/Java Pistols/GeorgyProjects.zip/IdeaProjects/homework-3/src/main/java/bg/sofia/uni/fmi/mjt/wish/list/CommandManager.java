package bg.sofia.uni.fmi.mjt.wish.list;

import java.nio.channels.SelectionKey;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CommandManager {

    private final Map<String, String> users;
    private final Map<String, Set<String>> wishes;
    private final ConnectionManager connections;

    private static final int COMMAND = 0;
    private static final int USERNAME = 1;
    private static final int PASSWORD = 2;
    private static final String USERNAME_VALIDATION = "^[a-zA-Z0-9_.-]*$";

    public CommandManager(ConnectionManager manager) {
        wishes = new HashMap<>();
        users = new HashMap<>();
        connections = manager;
    }

    public String process(String message, SelectionKey key) {
        List<String> arguments = new ArrayList<>(Arrays.asList(message.split(" ")));
        if (isValidCommand(arguments)) {
            return "[ Invalid number of parameters ]";
        }
        if (isNotInAccount(arguments, key)) {
            return "[ You are not logged in ]";
        }
        String result;

        result = switch (arguments.get(COMMAND)) {
            case "register" -> registerCommand(arguments);
            case "login" -> loginCommand(arguments, key);
            case "logout" -> logoutCommand(key);
            case "post-wish" -> postWishCommand(arguments);
            case "get-wish" -> getWishCommand(key);
            case "disconnect" -> "[ Disconnected from server ]";
            default -> "[ Unknown command ]";
        };

        return result;
    }

    private String registerCommand(List<String> arguments) {
        String username = arguments.get(USERNAME);
        String password = arguments.get(PASSWORD);

        if (!username.matches(USERNAME_VALIDATION)) {
            return "[ Username " + username + " is invalid, select a valid one ]";
        }
        if (users.containsKey(username)) {
            return "[ Username " + username + " is already taken, select another one ]";
        }

        users.put(username, password);
        return "[ Username " + username + " successfully registered ]";
    }

    private String loginCommand(List<String> arguments, SelectionKey key) {
        String username = arguments.get(USERNAME);
        String password = arguments.get(PASSWORD);

        if (users.containsKey(username) && users.get(username).equals(password)) {
            connections.addConnection(key, username);
            return "[ User " + username + " successfully logged in ]";
        }

        return "[ Invalid username/password combination ]";
    }

    private String logoutCommand(SelectionKey key) {
        connections.removeConnection(key);
        return "[ Successfully logged out ]";
    }

    private String postWishCommand(List<String> arguments) {
        String username = arguments.get(USERNAME);
        if (!users.containsKey(username)) {
            return "[ Student with username " + username + " is not registered ]";
        }

        StringBuilder toPrint = new StringBuilder();

        arguments.remove(COMMAND);
        arguments.remove(COMMAND);
        String gift = String.join(" ", arguments);

        if (!wishes.containsKey(username)) {
            wishes.put(username, new HashSet<>());
        }

        if (wishes.get(username).contains(gift)) {
            toPrint.append("[ The same gift for student ")
                    .append(username)
                    .append(" was already submitted ]");
        } else {
            toPrint.append("[ Gift ");

            wishes.get(username).add(gift);

            toPrint.append(gift)
                    .append(" for student ")
                    .append(username)
                    .append(" submitted successfully ]");

        }

        return toPrint.toString();
    }

    private String getWishCommand(SelectionKey key) {
        StringBuilder toPrint = new StringBuilder();
        wishes.entrySet()
                .stream()
                .filter((wish) -> !connections.getUsername(key).equals(wish.getKey()))
                .findAny()
                .ifPresentOrElse((entry) -> {
                    toPrint.append("[ ")
                            .append(entry.getKey())
                            .append(": ")
                            .append(entry.getValue().toString())
                            .append(" ]");

                    wishes.remove(entry.getKey());
                }, () -> toPrint.append("[ There are no students present in the wish list ]"));

        return toPrint.toString();
    }

    private boolean isNotInAccount(List<String> arguments, SelectionKey key) {
        String command = arguments.get(COMMAND);
        if (command.equals("logout")
                || command.equals("post-wish")
                || command.equals("get-wish")) {
            return connections.isNotLoggedIn(key);
        }
        return false;
    }

    private boolean isValidCommand(List<String> arguments) {
        String command = arguments.get(COMMAND);
        return (command.equals("register")
                || command.equals("login")
                || command.equals("post-wish"))
                && arguments.size() < 3;
    }
}
