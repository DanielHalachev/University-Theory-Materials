package bg.sofia.uni.fmi.mjt.wish.list;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.nio.channels.SelectionKey;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CommandManagerTest {

    @Mock
    private ConnectionManager connectionManager;
    @Mock
    private SelectionKey key;

    @Test
    public void testEmptyCommand() {
        CommandManager commandManager = new CommandManager(connectionManager);

        assertEquals("Empty command should return unknown command.",
                commandManager.process("", key), "[ Unknown command ]");
    }

    @Test
    public void testIfNotLoggedInUserCanUsePostWish() {
        when(connectionManager.isNotLoggedIn(key)).thenReturn(true);
        CommandManager commandManager = new CommandManager(connectionManager);

        assertEquals("Not logged in users should not be allowed to use post-wish command.",
                commandManager.process("post-wish Toshko 1234", key), "[ You are not logged in ]");
    }

    @Test
    public void testIfNotLoggedInUserCanUseGetWish() {
        when(connectionManager.isNotLoggedIn(key)).thenReturn(true);
        CommandManager commandManager = new CommandManager(connectionManager);

        assertEquals("Not logged in users should not be allowed to use get-wish command.",
                commandManager.process("get-wish Toshko 1234", key), "[ You are not logged in ]");
    }

    @Test
    public void testIfNotLoggedInUserCanLogout() {
        when(connectionManager.isNotLoggedIn(key)).thenReturn(true);
        CommandManager commandManager = new CommandManager(connectionManager);

        assertEquals("Not logged in users should not be allowed to use logout command.",
                commandManager.process("logout", key), "[ You are not logged in ]");
    }

    @Test
    public void testUsernameValidation() {
        CommandManager commandManager = new CommandManager(connectionManager);

        assertEquals("Usernames should not contain non-alphanumeric characters.",
                commandManager.process("register Th$ito 123", key),
                "[ Username Th$ito is invalid, select a valid one ]");
    }

    @Test
    public void testUserRegistration() {
        CommandManager commandManager = new CommandManager(connectionManager);

        assertEquals("User should be registered successfully.",
                commandManager.process("register Thito 123", key),
                "[ Username Thito successfully registered ]");
    }

    @Test
    public void testIfUsernameIsTaken() {
        CommandManager commandManager = new CommandManager(connectionManager);
        commandManager.process("register Thito 123", key);

        assertEquals("Username should be already taken.",
                commandManager.process("register Thito 123", key),
                "[ Username Thito is already taken, select another one ]");
    }

    @Test
    public void testLoginPasswordValidation() {
        CommandManager commandManager = new CommandManager(connectionManager);
        commandManager.process("register Thito 123", key);

        assertEquals("Users with invalid passwords should not be allowed to log in.",
                commandManager.process("login Thito 1233", key),
                "[ Invalid username/password combination ]");
    }

    @Test
    public void testLoginCorrectPassword() {
        CommandManager commandManager = new CommandManager(connectionManager);
        commandManager.process("register Thito 123", key);

        assertEquals("Users with invalid passwords should be allowed to log in.",
                commandManager.process("login Thito 123", key),
                "[ User Thito successfully logged in ]");
    }

    @Test
    public void testLogout() {
        CommandManager commandManager = new CommandManager(connectionManager);
        commandManager.process("register Thito 123", key);
        commandManager.process("login Thito 123", key);

        assertEquals("Logged in users should be allowed to logout.",
                commandManager.process("logout", key),
                "[ Successfully logged out ]");
    }

    @Test
    public void testPostWish() {
        CommandManager commandManager = new CommandManager(connectionManager);
        commandManager.process("register Thito 123", key);
        commandManager.process("login Thito 123", key);

        assertEquals("Gift should be submitted successfully.",
                commandManager.process("post-wish Thito avto kushta", key),
                "[ Gift avto kushta for student Thito submitted successfully ]");
    }

    @Test
    public void testPostWishSameGift() {
        CommandManager commandManager = new CommandManager(connectionManager);
        commandManager.process("register Thito 123", key);
        commandManager.process("login Thito 123", key);
        commandManager.process("post-wish Thito avto kushta", key);

        assertEquals("The same gift should not be posted again.",
                commandManager.process("post-wish Thito avto kushta", key),
                "[ The same gift for student Thito was already submitted ]");
    }

    @Test
    public void testPostWishForNonRegisteredUser() {
        CommandManager commandManager = new CommandManager(connectionManager);
        commandManager.process("register Thito 123", key);
        commandManager.process("login Thito 123", key);

        assertEquals("Unregistered users should not be allowed to have gifts.",
                commandManager.process("post-wish Thito1 avto kushta", key),
                "[ Student with username Thito1 is not registered ]");
    }

    @Test
    public void testGetWish() {
        when(connectionManager.getUsername(key)).thenReturn("Thito");
        CommandManager commandManager = new CommandManager(connectionManager);
        commandManager.process("register Thito 123", key);
        commandManager.process("register Zdravko 123", key);
        commandManager.process("login Thito 123", key);
        commandManager.process("post-wish Zdravko Tesla Rail Gun", key);
        commandManager.process("post-wish Zdravko vudica", key);

        assertEquals("Get-wish result should be returned.",
                commandManager.process("get-wish", key),
                "[ Zdravko: [Tesla Rail Gun, vudica] ]");
    }

    @Test
    public void testGetWishWithNoUsers() {
        when(connectionManager.getUsername(key)).thenReturn("Thito");
        CommandManager commandManager = new CommandManager(connectionManager);
        commandManager.process("register Thito 123", key);
        commandManager.process("register Zdravko 123", key);
        commandManager.process("login Thito 123", key);
        commandManager.process("post-wish Zdravko Tesla Rail Gun", key);
        commandManager.process("post-wish Zdravko vudica", key);
        commandManager.process("get-wish", key);

        assertEquals("There should not be any users left with wishes.",
                commandManager.process("get-wish", key),
                "[ There are no students present in the wish list ]");
    }

    @Test
    public void testDisconnect() {
        CommandManager commandManager = new CommandManager(connectionManager);

        assertEquals("User should be disconnected from the server.",
                commandManager.process("disconnect", key),
                "[ Disconnected from server ]");
    }

}
