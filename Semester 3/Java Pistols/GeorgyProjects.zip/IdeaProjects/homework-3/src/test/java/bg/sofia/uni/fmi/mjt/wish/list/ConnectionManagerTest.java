package bg.sofia.uni.fmi.mjt.wish.list;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.nio.channels.SelectionKey;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ConnectionManagerTest {

    @Mock
    private SelectionKey key;

    @Test
    public void testIfConnectionIsAdded() {
        ConnectionManager connectionManager = new ConnectionManager();
        connectionManager.addConnection(key, "User");

        assertEquals("Connection has not been added successfully.",
                connectionManager.getUsername(key), "User");
    }

    @Test
    public void testIfConnectionHasBeenRemoved() {
        ConnectionManager connectionManager = new ConnectionManager();
        connectionManager.addConnection(key, "User");
        connectionManager.removeConnection(key);

        assertTrue("Connection has not been remove successfully.",
                connectionManager.isNotLoggedIn(key));
    }

}
