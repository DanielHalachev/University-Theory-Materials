package bg.sofia.uni.fmi.mjt.socialmedia.exceptions;

public class UsernameNotFoundException extends RuntimeException {

    public UsernameNotFoundException() {
        super("The username has not been found in the system.");
    }

}
