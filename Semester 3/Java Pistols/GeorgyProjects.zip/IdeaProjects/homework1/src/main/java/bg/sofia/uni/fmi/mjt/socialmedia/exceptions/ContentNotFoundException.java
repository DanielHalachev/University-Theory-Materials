package bg.sofia.uni.fmi.mjt.socialmedia.exceptions;

public class ContentNotFoundException extends RuntimeException {

    public ContentNotFoundException() {
        super("Content has not been found in the system.");
    }

}
