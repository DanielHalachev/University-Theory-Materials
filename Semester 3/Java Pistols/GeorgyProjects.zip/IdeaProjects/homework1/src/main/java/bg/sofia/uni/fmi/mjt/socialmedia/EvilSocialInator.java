package bg.sofia.uni.fmi.mjt.socialmedia;

import bg.sofia.uni.fmi.mjt.socialmedia.content.AbstractContent;
import bg.sofia.uni.fmi.mjt.socialmedia.content.Content;
import bg.sofia.uni.fmi.mjt.socialmedia.content.Post;
import bg.sofia.uni.fmi.mjt.socialmedia.content.Story;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.ContentNotFoundException;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.NoUsersException;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.UsernameAlreadyExistsException;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.UsernameNotFoundException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class EvilSocialInator implements SocialMediaInator {

    private final Map<String, User> users;
    private final Map<String, Content> content;

    EvilSocialInator() {
        users = new HashMap<>();
        content = new HashMap<>();
    }

    @Override
    public void register(String username) {
        validateUserNotRegistered(username);
        users.put(username, new User(username));
    }

    @Override
    public String publishPost(String username, LocalDateTime publishedOn, String description) {
        validateContent(username, publishedOn, description);

        List<String> list = new ArrayList<>(Arrays.asList(description.split(" ")));

        Content post = new Post(username, publishedOn, getTags(list), getMentions(list));
        String id = post.getId();
        content.put(id, post);

        users.get(username).log("Created a post with id " + id, publishedOn);

        return id;
    }

    @Override
    public String publishStory(String username, LocalDateTime publishedOn, String description) {
        validateContent(username, publishedOn, description);

        List<String> list = new ArrayList<>(Arrays.asList(description.split(" ")));

        Content story = new Story(username, publishedOn, getTags(list), getMentions(list));
        String id = story.getId();
        content.put(id, story);

        users.get(username).log("Created a story with id " + id, publishedOn);

        return id;
    }

    @Override
    public void like(String username, String id) {
        validateUserRegistered(username);
        validateContentId(id);

        ((AbstractContent) content.get(id)).like();
        users.get(username).log("Liked a content with id " + id, LocalDateTime.now());
    }

    @Override
    public void comment(String username, String text, String id) {
        validateObjectNotNull(text, "Text of the comment cannot be null");
        validateUserRegistered(username);
        validateContentId(id);

        ((AbstractContent) content.get(id)).comment(text);
        users.get(username).log("Commented \"" + text + "\" on a content with id " + id, LocalDateTime.now());

    }

    @Override
    public Collection<Content> getNMostPopularContent(int n) {
        validateCollectionSize(n);

        List<Content> contentToSort = new LinkedList<>(content.values());
        contentToSort.sort(new Comparator<Content>() {
            public int compare(Content c1, Content c2) {
                AbstractContent content1 = (AbstractContent) c1;
                AbstractContent content2 = (AbstractContent) c2;

                return content2.getPopularity() - content1.getPopularity();
            }
        });

        return Collections.unmodifiableList(getNNotExpired(contentToSort, n));
    }

    @Override
    public Collection<Content> getNMostRecentContent(String username, int n) {
        validateUserRegistered(username);
        validateCollectionSize(n);

        List<Content> contentToSort = new LinkedList<>(content.values());

        Iterator<Content> contentIterator = contentToSort.iterator();
        while (contentIterator.hasNext()) {
            Content current = contentIterator.next();
            if (!((AbstractContent) current).getAuthor().equals(username)) {
                contentIterator.remove();
            }
        }

        contentToSort.sort(new Comparator<Content>() {
            public int compare(Content c1, Content c2) {
                AbstractContent content1 = (AbstractContent) c1;
                AbstractContent content2 = (AbstractContent) c2;

                return content2.getCreatedAt().compareTo(content1.getCreatedAt());
            }
        });

        return Collections.unmodifiableList(getNNotExpired(contentToSort, n));
    }

    @Override
    public String getMostPopularUser() {
        if (users.isEmpty()) {
            throw new NoUsersException();
        }
        User maxUser = users.values().iterator().next();
        for (User user : users.values()) {
            if (user.getPopularity() > maxUser.getPopularity()) {
                maxUser = user;
            }
        }
        return maxUser.getUsername();
    }

    @Override
    public Collection<Content> findContentByTag(String tag) {
        validateObjectNotNull(tag, "Tag cannot be null.");

        List<Content> result = new LinkedList<>();
        for (Content content : content.values()) {
            if (content.getTags().contains(tag) && ((AbstractContent) content).isNotExpired()) {
                result.add(content);
            }
        }
        return Collections.unmodifiableList(result);
    }

    @Override
    public List<String> getActivityLog(String username) {
        validateUserRegistered(username);

        return users.get(username).getActivityLog();
    }

    private boolean isUserRegistered(String username) {
        return users.containsKey(username);
    }

    private boolean isContentPublished(String id) {
        return content.containsKey(id);
    }

    private List<Content> getNNotExpired(List<Content> contentList, int n) {
        List<Content> result = new LinkedList<>();
        Iterator<Content> contentIterator = contentList.iterator();
        while (contentIterator.hasNext() && result.size() < n) {
            Content current = contentIterator.next();
            if (((AbstractContent) current).isNotExpired()) {
                result.add(current);
            }
        }
        return result;
    }

    private <T> void validateObjectNotNull(T object, String message) {
        if (object == null) {
            throw new IllegalArgumentException(message);
        }
    }

    private void validateContentId(String id) {
        validateObjectNotNull(id, "ID cannot be null.");

        if (!isContentPublished(id)) {
            throw new ContentNotFoundException();
        }
    }

    private void validateUserNotRegistered(String username) {
        validateObjectNotNull(username, "Username cannot be null.");

        if (isUserRegistered(username)) {
            throw new UsernameAlreadyExistsException();
        }
    }

    private void validateUserRegistered(String username) {
        validateObjectNotNull(username, "Username cannot be null.");

        if (!isUserRegistered(username)) {
            throw new UsernameNotFoundException();
        }
    }

    private void validateCollectionSize(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("N cannot be negative.");
        }
    }

    private void validateContent(String username, LocalDateTime publishedOn, String description) {
        validateUserRegistered(username);
        validateObjectNotNull(publishedOn, "Date of publication cannot be null.");
        validateObjectNotNull(description, "Description cannot be null.");
    }

    private Set<String> getTags(List<String> items) {
        Set<String> result = new TreeSet<>();
        for (String item : items) {
            if (!item.isEmpty() && item.charAt(0) == '#') {
                result.add(item);
            }
        }
        return result;
    }

    private Set<String> getMentions(List<String> items) {
        Set<String> result = new TreeSet<>();
        for (String item : items) {
            if (!item.isEmpty() && item.charAt(0) == '@' && isUserRegistered(item.substring(1))) {
                result.add(item);
                users.get(item.substring(1)).increasePopularity();
            }
        }
        return result;
    }
}
