package bg.sofia.uni.fmi.mjt.socialmedia.content;

import java.time.LocalDateTime;
import java.util.Set;

public class Post extends AbstractContent {

    private final static int daysToExpire = 30;

    public Post(String username, LocalDateTime date, Set<String> tags, Set<String> mentions) {
        super(username, date, tags, mentions, daysToExpire);
    }

}
