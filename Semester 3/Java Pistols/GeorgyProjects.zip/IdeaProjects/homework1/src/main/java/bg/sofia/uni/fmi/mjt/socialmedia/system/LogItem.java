package bg.sofia.uni.fmi.mjt.socialmedia.system;

import java.time.LocalDateTime;

public record LogItem(LocalDateTime date, String data) implements Comparable<LogItem> {

    @Override
    public int compareTo(LogItem o) {
        return o.date.compareTo(date);
    }
}
