package bg.sofia.uni.fmi.mjt.socialmedia.content;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public abstract class AbstractContent implements Content {

    private final int daysToExpire;
    private static int count = 0;

    private int likes;
    private final LocalDateTime createdAt;
    private final List<String> comments;
    private final Set<String> tags;
    private final Set<String> mentions;
    private final String author;

    protected String id;

    AbstractContent(String username, LocalDateTime date, Set<String> tags, Set<String> mentions, int daysToExpire) {
        this.comments = new ArrayList<>();
        this.tags = new TreeSet<>(tags);
        this.mentions = new TreeSet<>(mentions);

        this.author = username;
        this.createdAt = date;
        this.daysToExpire = daysToExpire;
        this.likes = 0;

        id = username + '-' + count;
        ++count;
    }

    @Override
    public int getNumberOfComments() {
        return comments.size();
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public int getNumberOfLikes() {
        return likes;
    }

    @Override
    public Collection<String> getTags() {
        return tags;
    }

    @Override
    public Collection<String> getMentions() {
        return mentions;
    }

    public void like() {
        ++likes;
    }

    public void comment(String comment) {
        comments.add(comment);
    }

    public int getPopularity() {
        return likes + comments.size();
    }

    public boolean containsTag(String tag) {
        return tags.contains(tag);
    }

    public boolean isNotExpired() {
        return createdAt.plusDays(daysToExpire).isAfter(LocalDateTime.now());
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public String getAuthor() {
        return author;
    }
}
