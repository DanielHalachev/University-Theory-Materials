package bg.sofia.uni.fmi.mjt.socialmedia;

import bg.sofia.uni.fmi.mjt.socialmedia.system.LogItem;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class User {

    private final Set<LogItem> activityLog;
    private int popularity;
    private final String username;

    public User(String name) {
        activityLog = new TreeSet<>();
        popularity = 0;
        username = name;
    }

    public List<String> getActivityLog() {
        List<String> result = new LinkedList<>();
        for (var item : activityLog) {
            result.add(item.data());
        }
        return result;
    }

    public void log(String action, LocalDateTime date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss dd.MM.yy");
        activityLog.add(new LogItem(date, date.format(formatter) + ": " + action));
    }

    public int getPopularity() {
        return popularity;
    }

    public void increasePopularity() {
        ++popularity;
    }

    public String getUsername() {
        return username;
    }
}
