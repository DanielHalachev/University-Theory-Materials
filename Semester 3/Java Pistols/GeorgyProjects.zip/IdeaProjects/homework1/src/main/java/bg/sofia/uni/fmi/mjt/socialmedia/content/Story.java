package bg.sofia.uni.fmi.mjt.socialmedia.content;

import java.time.LocalDateTime;
import java.util.Set;

public class Story extends AbstractContent {

    private final static int daysToExpire = 1;

    public Story(String username, LocalDateTime date, Set<String> tags, Set<String> mentions) {
        super(username, date, tags, mentions, daysToExpire);
    }

}
