package bg.sofia.uni.fmi.mjt.spellchecker;

import org.junit.Test;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class NaiveSpellCheckerTest {

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorForValidationOfTheFirstArgument() {
        Reader stopWordsReader = new StringReader(simpleStopwords);
        new NaiveSpellChecker(null, stopWordsReader);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorForValidationOfTheSecondArgument() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        new NaiveSpellChecker(dictionaryReader, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFindClosestWordsValidationOnTheFirstArgument() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        spellChecker.findClosestWords(null, 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFindClosestWordsValidationOnTheSecondArgument() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        spellChecker.findClosestWords("hi", -1);
    }

    @Test
    public void testFindClosestWordsWithZero() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        List<String> actual = spellChecker.findClosestWords("hohoho", 0);

        assertTrue(actual.isEmpty());
    }

    @Test
    public void testFindClosestWordsWithSimpleExample() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        List<String> actual = spellChecker.findClosestWords("hohohlo", 3);
        List<String> expected = List.of("hot", "thos", "thoss");
        assertEquals(expected, actual);
    }

    @Test
    public void testFindClosestWordsWithNotFormattedExample() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        List<String> actual = spellChecker.findClosestWords("       $%^&*()Next ^&*( ", 2);
        List<String> expected = List.of("near", "excellent");
        assertEquals(expected, actual);
    }

    @Test
    public void testFindClosestWordsWithComplexExample() {
        Reader dictionaryReader = new StringReader(complexDictionary);
        Reader stopWordsReader = new StringReader(complexStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        List<String> actual = spellChecker.findClosestWords("/*/-*/*-*/*        Dogii\n\n\n\r", 3);
        List<String> expected = List.of("dog", "igiihoroto", "igihoroto");
        assertEquals(expected, actual);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMetadataValidation() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        spellChecker.metadata(null);
    }

    @Test
    public void testMetadataSimpleExample() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        String input = "Hello, this is a simple sentence.\nThis is another sentence.";
        Reader reader = new StringReader(input);
        Metadata actual = spellChecker.metadata(reader);
        Metadata expected = new Metadata(input.length() - 9, 7, 6);

        assertEquals(expected, actual);
    }

    @Test
    public void testMetadataNotFormattedExample() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        String input = "%^&*()Hello,      /*-***---*--*//  this is a simple&*( sentence.\n\n\n\n\nThis is "
                + "another$%^&*())  \n%^&*())&^%$%^&*\n sentence^&*().";
        Reader reader = new StringReader(input);
        Metadata actual = spellChecker.metadata(reader);
        Metadata expected = new Metadata(input.length() - 24, 7, 6);

        assertEquals(expected, actual);
    }

    @Test
    public void testMetadataComplexExample() {
        Reader dictionaryReader = new StringReader(complexDictionary);
        Reader stopWordsReader = new StringReader(complexStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        String input = "%^&*()89HeLLo,%^& *()near    not you've  /*-***---*--*//\n$%^&*()  Jonsans' is a simple&"
                + "*( sentence.\n\n\n\n\nThis is %^&*()(*&^%\n"
                + "another$%^&*())  \n%^&*())&^%$%^&*\n sentence^&*().\n";
        Reader reader = new StringReader(input);
        Metadata actual = spellChecker.metadata(reader);
        Metadata expected = new Metadata(input.length() - 29, 9, 7);

        assertEquals(expected, actual);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAnalyzeValidation() {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        try {
            Writer output = new StringWriter();
            spellChecker.analyze(null, output, 2);
            output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void testAnalyzeSimpleExample() throws IOException {
        Reader dictionaryReader = new StringReader(simpleDictionary);
        Reader stopWordsReader = new StringReader(simpleStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        String input = "Hello, this is a simple sentence.\nThis is another sentence.";
        Writer actual;

        Reader reader = new StringReader(input);
        actual = new StringWriter();
        spellChecker.analyze(reader, actual, 3);
        actual.close();

        Writer expected = new StringWriter();
        expected.write(input);
        expected.write("""
                
                = = = Metadata = = =
                50 characters, 7 words, 6 spelling issue(s) found
                = = = Findings = = =
                Line #1, {this} - Possible suggestions are {thos, thoss, other}
                Line #1, {simple} - Possible suggestions are {simpler, simplyy, simpy}
                Line #1, {sentence} - Possible suggestions are {sentency, sentenccy, sentenccce}
                Line #2, {this} - Possible suggestions are {thos, thoss, other}
                Line #2, {another} - Possible suggestions are {anothers, other, othery}
                Line #2, {sentence} - Possible suggestions are {sentency, sentenccy, sentenccce}""");

        assertEquals(expected.toString(), actual.toString());
    }

    @Test
    public void testAnalyzeComplexExample() throws IOException {
        Reader dictionaryReader = new StringReader(complexDictionary);
        Reader stopWordsReader = new StringReader(complexStopwords);
        SpellChecker spellChecker = new NaiveSpellChecker(dictionaryReader, stopWordsReader);

        String input = "%^&*()89HeLLo,%^& *()near    not you've  /*-***---*--*//\n$%^&*()  Jonsans' is a simple&"
                + "*( sentence.\n\n\n\n\nThis is %^&*()(*&^%\n"
                + "another$%^&*())  \n%^&*())&^%$%^&*\n sentence^&*().\n";
        Writer actual;

        Reader reader = new StringReader(input);
        actual = new StringWriter();
        spellChecker.analyze(reader, actual, 3);
        actual.close();

        Writer expected = new StringWriter();
        expected.write(input);
        expected.write("""
                
                = = = Metadata = = =
                145 characters, 9 words, 7 spelling issue(s) found
                = = = Findings = = =
                Line #1, {not} - Possible suggestions are {noty, nonoty, nono}
                Line #2, {jonsans} - Possible suggestions are {jonsansy, jonsanny, joan}
                Line #2, {simple} - Possible suggestions are {simply, simplium, sim}
                Line #2, {sentence} - Possible suggestions are {senty, sentancy, sentancium}
                Line #7, {this} - Possible suggestions are {thisy, thisyy, thos}
                Line #8, {another} - Possible suggestions are {anothery, anotheryy, other}
                Line #10, {sentence} - Possible suggestions are {senty, sentancy, sentancium}""");

        assertEquals(expected.toString(), actual.toString());
    }

    private final String simpleStopwords = String.join(System.lineSeparator(), List.of("a  ", "am", "me", "is"));
    private final String simpleDictionary = String.join(
            System.lineSeparator(), List.of(
                    "Hello", "Dog", "Near", "Nice", "Hot", "Cold", "Ice", "Left", "Right", "Hororororo", "Excellent",
                    "thos", "thoss", "thosss", "simpy", "simplyy", "simpler", "sentency", "sentenccy", "sentenccce",
                    "other", "anothers", "othery"
            )
    );

    private final String complexStopwords = String.join(
            System.lineSeparator(), List.of(
                    " you'd  \n\n\n\n",
                    "       you'll\n",
                    "you're     \n",
                    "   you've   ",
                    "   am",
                    "me    ",
                    "   shan't\n",
                    "\n\rshe\n",
                    "   she'd\n",
                    "   she'll \n",
                    "   Jonsans' \n",
                    "sHe's\n        ",
                    "   sHould\n",
                    "   shoulDn't       ",
                    "is",
                    "a"
            )
    );
    private final String complexDictionary = String.join(
            System.lineSeparator(), List.of(
                    "  ^&*89Hello    ",
                    "%^&^%^&Dog   ",
                    "      %^&*&^%^Near",
                    "++   ^&&^Nice**  **",
                    "Hot++++++++++",
                    "Cold/*/\n\n\n\n\\--*-",
                    "  %^&*(*&^% Ice ****",
                    "       Left995",
                    "Right475^&*()\n  ^&*()",
                    "   **&^& 754Hororororo  *)*)(* (*&*()(*&*",
                    "   **&^& IGIhoroto  *)*)(* (*&*()(*&*",
                    "   **&^& IGIIhoroto  *)*)(* (*&*()(*&*",
                    "/*-/**/*/ 78Excellent36\n",
                    "%€§*    §**§*(  noty",
                    "%€§*    §**§*(  nono",
                    "nonoty*§€§*((     ",
                    "jonsansy",
                    "jonsanny*§€§*((     ",
                    "joan*§€§*((     ",
                    "%€§*    §**§*(  simply",
                    "simplium",
                    "sim",
                    "sentancium",
                    "sentancy",
                    "%€§*    §**§*(  senty",
                    "anothery",
                    "anotheryy*§€§*((     ",
                    "other",
                    "thisy",
                    "thos*§€§*((     ",
                    "thisyy"
            )
    );
}