package bg.sofia.uni.fmi.mjt.spellchecker;

import bg.sofia.uni.fmi.mjt.spellchecker.validation.Validate;

public class MutableMetadata {

    public MutableMetadata(int characters, int words, int mistakes) {
        Validate.validateNonNegativeNumber(characters);
        Validate.validateNonNegativeNumber(words);
        Validate.validateNonNegativeNumber(mistakes);

        this.characters = characters;
        this.words = words;
        this.mistakes = mistakes;
    }

    public void addCharacters(int n) {
        Validate.validateNonNegativeNumber(n);

        characters += n;
    }

    public void incrementMistakes() {
        ++mistakes;
    }

    public void incrementWords() {
        ++words;
    }

    @Override
    public String toString() {
        return characters + " characters, " + words + " words, " + mistakes + " spelling issue(s) found";
    }

    public Metadata toImmutable() {
        return new Metadata(characters, words, mistakes);
    }

    private int characters;
    private int words;
    private int mistakes;
}