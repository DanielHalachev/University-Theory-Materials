package bg.sofia.uni.fmi.mjt.spellchecker;

import bg.sofia.uni.fmi.mjt.spellchecker.validation.Validate;
import bg.sofia.uni.fmi.mjt.spellchecker.words.Word;
import bg.sofia.uni.fmi.mjt.spellchecker.words.WordSimilarity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

public class NaiveSpellChecker implements SpellChecker {

    /**
     * Creates a new instance of NaiveSpellCheckTool, based on a dictionary of words and stop words
     *
     * @param dictionaryReader a java.io.Reader input stream containing list of words which will serve as a dictionary
     * @param stopwordsReader a java.io.Reader input stream containing list of stopwords
     */
    public NaiveSpellChecker(Reader dictionaryReader, Reader stopwordsReader) {
        Validate.validate(dictionaryReader, "Dictionary reader cannot be null.");
        Validate.validate(stopwordsReader, "Dictionary reader cannot be null.");

        BufferedReader dictionaryBufferedReader = new BufferedReader(dictionaryReader);
        BufferedReader stopWordsBufferedReader = new BufferedReader(stopwordsReader);

        dictionary = dictionaryBufferedReader.lines()
                .map(String::strip)
                .map(NaiveSpellChecker::stripNonAlphanumeric)
                .filter((word) -> word.length() >= 2)
                .map(Word::new)
                .collect(Collectors.toCollection(HashSet::new));

        stopWords = stopWordsBufferedReader.lines()
                .map(String::strip)
                .map(Word::new)
                .collect(Collectors.toCollection(HashSet::new));

    }

    public void analyze(Reader textReader, Writer output, int suggestionsCount) {
        Validate.validate(textReader, "Text reader cannot be null.");
        Validate.validate(output, "Output reader cannot be null.");
        Validate.validateNonNegativeNumber(suggestionsCount);

        Scanner scanner = new Scanner(textReader);
        scanner.useDelimiter("(?=\\s)");

        StringBuilder findingsResult = new StringBuilder();
        findingsResult.append("= = = Findings = = =\n");

        int numberOfLines = 1;
        MutableMetadata metadata = new MutableMetadata(0, 0, 0);

        try {
            String word;
            while (scanner.hasNext()) {
                word = scanner.next();
                output.write(word);
                if (word.startsWith("\n")) {
                    ++numberOfLines;
                }

                calculateMetadata(word.strip(), metadata);
                Word correction = new Word(stripNonAlphanumeric(word));
                int length = correction.getString().length();
                if (length > 0 && !stopWords.contains(correction) && !dictionary.contains(correction)) {
                    List<String> suggestions = findClosestWords(correction.getString(), suggestionsCount);
                    findingsResult.append(formatSuggestion(numberOfLines, correction.getString(), suggestions));
                }
            }

            output.write("\n= = = Metadata = = =\n");
            output.write(metadata.toString() + "\n");
            findingsResult.deleteCharAt(findingsResult.length() - 1);
            output.write(findingsResult.toString());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public Metadata metadata(Reader textReader) {
        Validate.validate(textReader, "Text reader cannot be null.");

        MutableMetadata metadata = new MutableMetadata(0, 0, 0);
        Scanner scanner = new Scanner(textReader);
        String word;
        while (scanner.hasNext()) {
            word = scanner.next();
            calculateMetadata(word, metadata);
            word = "";
        }

        return metadata.toImmutable();
    }

    public List<String> findClosestWords(String word, int n) {
        Validate.validate(word, "The given word cannot be null.");
        Validate.validateNonNegativeNumber(n);

        Word toMatch = new Word(stripNonAlphanumeric(word));
        return dictionary.stream()
                .map((dictionaryWord) -> new WordSimilarity(dictionaryWord, toMatch))
                .sorted()
                .map(WordSimilarity::getWordAsString)
                .limit(n)
                .collect(Collectors.toList());
    }

    private void calculateMetadata(String word, MutableMetadata mutableMetadata) {
        int length = word.length();
        mutableMetadata.addCharacters(length);
        Word toWord = new Word(stripNonAlphanumeric(word));
        if (toWord.getString().length() > 0 && !stopWords.contains(toWord)) {
            mutableMetadata.incrementWords();
            if (!dictionary.contains(toWord)) {
                mutableMetadata.incrementMistakes();
            }
        }
    }

    private static String formatSuggestion(int lineNumber, String word, List<String> suggestions) {
        return "Line #" + lineNumber + ", {" + word + "} - Possible suggestions are {"
                + stripNonAlphanumeric(suggestions.toString()) + "}\n";
    }

    private static String stripNonAlphanumeric(String word) {
        StringBuilder result = new StringBuilder(word);
        while (result.length() > 0 && !Character.isLetterOrDigit(result.charAt(0))) {
            result.deleteCharAt(0);
        }

        while (result.length() > 0 && !Character.isLetterOrDigit(result.charAt(result.length() - 1))) {
            result.deleteCharAt(result.length() - 1);
        }

        return result.toString();
    }

    private final Set<Word> dictionary;
    private final Set<Word> stopWords;
}
