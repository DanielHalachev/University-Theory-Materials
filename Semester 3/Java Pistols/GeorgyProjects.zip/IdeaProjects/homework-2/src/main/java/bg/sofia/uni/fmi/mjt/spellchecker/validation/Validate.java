package bg.sofia.uni.fmi.mjt.spellchecker.validation;

import bg.sofia.uni.fmi.mjt.spellchecker.words.Word;

public class Validate {

    public static <T> void validate(T object, String message) {
        if (object == null) {
            throw new IllegalArgumentException(message);
        }
    }

    public static void validateWords(Word word1, Word word2) {
        validate(word1, "The first argument cannot be null.");
        validate(word2, "The second argument cannot be null.");
    }

    public static void validateNonNegativeNumber(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("The given number cannot be negative.");
        }
    }
}
