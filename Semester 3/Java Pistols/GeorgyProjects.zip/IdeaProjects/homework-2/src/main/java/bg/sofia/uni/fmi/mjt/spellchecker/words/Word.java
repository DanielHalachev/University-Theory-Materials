package bg.sofia.uni.fmi.mjt.spellchecker.words;

import bg.sofia.uni.fmi.mjt.spellchecker.validation.Validate;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Word {

    public Word(String from) {
        Validate.validate(from, "The given word in the constructor cannot be null.");

        string = from.toLowerCase();
        grams = new HashMap<>();
        for (int i = 0; i < string.length() - N + 1; ++i) {
            String currentGram = string.substring(i, N + i);
            if (grams.containsKey(currentGram)) {
                grams.put(currentGram, grams.get(currentGram) + 1);
            } else {
                grams.put(currentGram, 1);
            }
        }

        length = vectorLength();
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        Word word1 = (Word) other;
        return string.equals(word1.string);
    }

    @Override
    public int hashCode() {
        return Objects.hash(string);
    }

    @Override
    public String toString() {
        return "Word{"
                + "string='" + string + '\''
                + ", grams=" + grams
                + ", length=" + length
                + '}';
    }

    public String getString() {
        return string;
    }

    public static double cosineSimilarity(Word word1, Word word2) {
        Validate.validateWords(word1, word2);

        return dotProduct(word1, word2) / (word1.length * word2.length);
    }

    private double vectorLength() {
        int result = 0;
        for (var gramOccurrences : grams.values()) {
            result += gramOccurrences * gramOccurrences;
        }
        return Math.sqrt(result);
    }

    private static int dotProduct(Word word1, Word word2) {
        Validate.validateWords(word1, word2);

        int result = 0;
        for (var gram : word1.grams.entrySet()) {
            if (word2.grams.containsKey(gram.getKey())) {
                result += word2.grams.get(gram.getKey()) * gram.getValue();
            }
        }
        return result;
    }

    private static final int N = 2;
    private final String string;
    private final Map<String, Integer> grams;
    private final double length;
}
