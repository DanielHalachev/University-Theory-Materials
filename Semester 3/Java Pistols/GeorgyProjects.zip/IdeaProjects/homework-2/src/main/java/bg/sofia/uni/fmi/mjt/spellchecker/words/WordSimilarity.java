package bg.sofia.uni.fmi.mjt.spellchecker.words;

import bg.sofia.uni.fmi.mjt.spellchecker.validation.Validate;

public class WordSimilarity implements Comparable<WordSimilarity> {

    public WordSimilarity(Word from, Word match) {
        Validate.validateWords(from, match);

        word = from;
        cosineSimilarity = Word.cosineSimilarity(from, match);
    }

    public String getWordAsString() {
        return word.getString();
    }

    @Override
    public int compareTo(WordSimilarity other) {
        Validate.validate(other, "The object that is being compared cannot be null.");

        return Double.compare(other.cosineSimilarity, cosineSimilarity);
    }

    private final Word word;
    private final double cosineSimilarity;
}
